==========================
local.conf - User Settings
==========================

``local.conf`` is a user-maintained settings file that is sourced in
``stackrc``. It contains a section that replaces the historical
``localrc`` file. See the description of
:doc:`local.conf <configuration>` for more details about the mechanics
of the file.
