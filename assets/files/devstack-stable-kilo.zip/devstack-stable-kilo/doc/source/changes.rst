=======
Changes
=======

Recent Changes What's been happening?
=====================================

These are the commits to DevStack for the last six months. For the
complete list see `the DevStack project in
Gerrit <https://review.openstack.org/#/q/status:merged+project:openstack-dev/devstack,n,z>`__.

%GIT_LOG%
